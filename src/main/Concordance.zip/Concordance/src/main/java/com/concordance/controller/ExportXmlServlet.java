package com.concordance.controller;

import java.io.Console;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.concordance.dao.GroupsDAO;
import com.concordance.dao.SongsDAO;
import com.concordance.model.Group;
import com.concordance.model.Song;
import com.concordance.utils.DBConnection;

public class ExportXmlServlet extends HttpServlet {

    private static final String URL = "jdbc:postgresql://localhost:5432/mydb";
    private static final String USER = "postgres";
    private static final String PASS = "mypassword";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {

        long ts = System.currentTimeMillis();
        String fileName = "db_backup_" + ts + ".xml";

        // Choose your folder:
        File file = new File("C:/temp/" + fileName);

        try (Connection conn =  DBConnection.getConnection();
             PrintWriter out = new PrintWriter(new FileWriter(file))) {

            DatabaseMetaData meta = conn.getMetaData();

            out.println("<database name=\"mydb\">");

            ResultSet tables = meta.getTables(null, "public", "%", new String[]{"TABLE"});

            while (tables.next()) {
                String table = tables.getString("TABLE_NAME");
                out.println("\t<table name=\"" + table + "\">");

                // ---- Columns ----
                out.println("\t\t<columns>");
                ResultSet cols = meta.getColumns(null, "public", table, "%");
                while (cols.next()) {
                    out.printf("\t\t\t<column name=\"%s\" type=\"%s\" notNull=\"%s\" />\n",
                            cols.getString("COLUMN_NAME"),
                            cols.getString("TYPE_NAME"),
                            (cols.getInt("NULLABLE") == DatabaseMetaData.columnNoNulls)
                    );
                }
                out.println("\t\t</columns>");

                // ---- Constraints ----
                out.println("\t\t<constraints>");

                // PK
                ResultSet pk = meta.getPrimaryKeys(null, "public", table);
                while (pk.next()) {
                    out.println("\t\t\t<primaryKey name=\"" + pk.getString("PK_NAME") + "\">");
                    out.println("\t\t\t\t<column>" + pk.getString("COLUMN_NAME") + "</column>");
                    out.println("\t\t\t</primaryKey>");
                }

                // FK
                ResultSet fk = meta.getImportedKeys(null, "public", table);
                while (fk.next()) {
                    out.printf(
                        "\t\t\t<foreignKey name=\"%s\" refTable=\"%s\">\n",
                        fk.getString("FK_NAME"),
                        fk.getString("PKTABLE_NAME")
                    );
                    out.println("\t\t\t\t<column>" + fk.getString("FKCOLUMN_NAME") + "</column>");
                    out.println("\t\t\t\t<refColumn>" + fk.getString("PKCOLUMN_NAME") + "</refColumn>");
                    out.println("\t\t\t</foreignKey>");
                }

                // Check + Unique
             // Get constraints safely, supporting uppercase table names
                PreparedStatement cs = conn.prepareStatement(
                    "SELECT c.conname, c.contype, pg_get_constraintdef(c.oid) AS def " +
                    "FROM pg_constraint c " +
                    "JOIN pg_class t ON c.conrelid = t.oid " +
                    "JOIN pg_namespace n ON n.oid = t.relnamespace " +
                    "WHERE t.relname = ? AND n.nspname = 'public'"
                );
                cs.setString(1, table);  // <-- Works even if tableName = "Groups"
                ResultSet cr = cs.executeQuery();

                while (cr.next()) {
                    String type = cr.getString("contype");
                    String name = cr.getString("conname");
                    String def = cr.getString("def");

                    if (type.equals("u")) {
                        out.println("\t\t\t<unique name=\"" + name + "\">" + def + "</unique>");
                    } else if (type.equals("c")) {
                        out.println("\t\t\t<check name=\"" + name + "\">" + def + "</check>");
                    }
                }

                out.println("\t\t</constraints>");

                // ---- Data ----
                out.println("\t\t<rows>");

                Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery("SELECT * FROM " + "\""+table+"\"");

                while (rs.next()) {
                    out.println("\t\t\t<row>");
                    ResultSetMetaData rmeta = rs.getMetaData();
                    for (int i = 1; i <= rmeta.getColumnCount(); i++) {
                        String colName = rmeta.getColumnName(i);
                        Object val = rs.getObject(i);
                        out.println("\t\t\t\t<" + colName + ">" +
                                (val == null ? "" : val) +
                                "</" + colName + ">");
                    }
                    out.println("\t\t\t</row>");
                }

                out.println("\t\t</rows>");

                out.println("\t</table>");
            }

            out.println("</database>");

        } catch (Exception e) {
            resp.setContentType("text/html");
            resp.getWriter().println("Error: " + e.getMessage());
            return;
        }

        // Show download link to the user
        resp.setContentType("text/html");
        resp.getWriter().println("<h3>Backup created successfully!</h3>");
        resp.getWriter().println("<a href=\"/download?file=" + fileName + "\">Download XML</a>");
    }
}
