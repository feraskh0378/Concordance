package com.concordance.controller; 

import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;


import com.concordance.dao.WordsDAO;
import com.concordance.model.Word;


public class GetWordsOptionsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException {
    	WordsDAO dao = new WordsDAO();
    	dao.initConnection();
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        ArrayList<Word> words = dao.getAllWords();
        try
        {
        	PrintWriter out = response.getWriter();
        	boolean printComma = false;
        	 out.print("[");
             for(Word w : words ) 
             {
            	 if(printComma)
            	 {            		 
            		 out.print(",");
            	 }
            	 printComma = true;
             	 out.print("{ \"id\":\""+w.getId()+"\",\"name\":\""+w.getWord()+"\"  }");             	
             }
             out.print("]");
             out.flush();
        }
        catch(Exception e)
        {
        	
        }
       
    }
}