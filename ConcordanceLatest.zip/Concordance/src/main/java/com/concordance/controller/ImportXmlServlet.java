package com.concordance.controller;




import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.concordance.utils.DBConnection;

public class ImportXmlServlet extends HttpServlet 
{

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException {

        Part filePart = req.getPart("file");
        File xmlFile = File.createTempFile("import", ".xml");
        filePart.write(xmlFile.getAbsolutePath());

        try (Connection conn =  DBConnection.getConnection();) 
        {
            conn.setAutoCommit(false);

            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            Document doc = f.newDocumentBuilder().parse(xmlFile);
            NodeList tables = doc.getElementsByTagName("table");

            //--------------------------------------
            // 1️⃣ CREATE TABLES (NO CONSTRAINTS)
            //--------------------------------------
            HashMap<String,String> colsTypes = new HashMap<String,String> ();
            for (int i = 0; i < tables.getLength(); i++) {
                Element table = (Element) tables.item(i);
                String tableName = table.getAttribute("name");

                NodeList columnsTags = table.getElementsByTagName("columns");
                if(columnsTags.getLength() != 1)
                {
                	throw new IOException("Error");
                }
                
                Element columnsTag = (Element) columnsTags.item(0);
                
                NodeList cols = columnsTag.getElementsByTagName("column");

                StringBuilder sql = new StringBuilder();
                sql.append("CREATE TABLE IF NOT EXISTS \"")
                   .append(tableName)
                   .append("\" (");

                for (int c = 0; c < cols.getLength(); c++) 
                {
                    Element col = (Element) cols.item(c);
                    colsTypes.put(col.getAttribute("name"), col.getAttribute("type"));
                    sql.append("\"").append(col.getAttribute("name")).append("\" ")
                       .append(col.getAttribute("type"));

                    if ("false".equals(col.getAttribute("nullable"))) 
                    {
                        sql.append(" NOT NULL");
                    }
                    sql.append(",");
                }
                sql.setLength(sql.length() - 1);
                sql.append(")");

                conn.createStatement().executeUpdate(sql.toString());
            }

            //--------------------------------------
            // 2️⃣ INSERT DATA
            //--------------------------------------
            for (int i = 0; i < tables.getLength(); i++) {
                Element table = (Element) tables.item(i);
                String tableName = table.getAttribute("name");

                NodeList rows = table.getElementsByTagName("row");

                for (int r = 0; r < rows.getLength(); r++) {
                    Element row = (Element) rows.item(r);
                    NodeList fields = row.getChildNodes();

                    StringBuilder cols = new StringBuilder();
                    StringBuilder vals = new StringBuilder();

                    for (int f2 = 0; f2 < fields.getLength(); f2++) 
                    {
                        if (fields.item(f2).getNodeType() != Node.ELEMENT_NODE) continue;
                        Element col = (Element) fields.item(f2);
                         
                        cols.append("\"").append(col.getTagName()).append("\",");
                        vals.append("?").append(",");
                    }

                    String sql = "INSERT INTO \"" + tableName + "\"(" +
                            cols.substring(0, cols.length() - 1) +
                            ") VALUES (" +
                            vals.substring(0, vals.length() - 1) +
                            ")" ;

                    PreparedStatement ps = conn.prepareStatement(sql);

                    int idx = 1;
                    for (int f2 = 0; f2 < fields.getLength(); f2++) 
                    {
                    	
                        if (fields.item(f2).getNodeType() != Node.ELEMENT_NODE)
                        {
                        	continue;
                        }
                        Element col = (Element) fields.item(f2);
                       
                        if(colsTypes.get(col.getTagName()).contains("int"))
                        {
                        	ps.setInt(idx++, Integer.parseInt(col.getTextContent()) );
                        }
                        else
                        	if(colsTypes.get(col.getTagName()).contains("date"))
                        	{
                        		java.sql.Date D = java.sql.Date.valueOf(col.getTextContent());
                        		
                        		ps.setDate(idx++, D);
                        	}
                        	else
                        	{
                        		ps.setString(idx++, col.getTextContent());
                        	}
                    }

                    ps.executeUpdate();
                   
                }
            }

            //--------------------------------------
            // 3️⃣ CREATE CONSTRAINTS
            //--------------------------------------
            for (int i = 0; i < tables.getLength(); i++) {
                Element table = (Element) tables.item(i);
                String tableName = table.getAttribute("name");

                NodeList cons = table.getElementsByTagName("constraints");
                if(cons.getLength() != 1)
                {
                	throw new IOException("Error");
                }
                
                NodeList constraints = cons.item(0).getChildNodes();
                for (int c = 0; c < constraints.getLength(); c++) 
                {
                	
                	if (constraints.item(c).getNodeType() != Node.ELEMENT_NODE)
                    {
                    	continue;
                    }
                    Element con = (Element) constraints.item(c);
                    String sql =
                            "ALTER TABLE \"" + tableName + "\" ADD CONSTRAINT ";
                    
                    String sql2 =
                            "ALTER TABLE \"" + tableName + "\" ALTER COLUMN ";
                    if(con.getTagName().equals("primaryKey"))
                    {
                    	sql = sql + "\""+con.getAttribute("name")+"\"";
                    	sql = sql + "PRIMARY KEY ";
                    	NodeList cols = con.getElementsByTagName("column");
                    	Element col = (Element) cols.item(0);
                    	sql = sql + "(\""+col.getTextContent()+"\")";
                    	
                    	sql2 = sql2 + "\"" + col.getTextContent()  + "\"" + " \n ADD GENERATED ALWAYS AS IDENTITY \n ( \n START WITH 1 \n INCREMENT BY 1 \n )";
                    			
                    }
                    else
                    {
                    	 if(con.getTagName().equals("foreignKey"))
                         {
                         	sql = sql + "\""+con.getAttribute("name")+"\"";
                         	sql = sql + " FOREIGN KEY ";
                         	NodeList cols = con.getElementsByTagName("column");
                         	Element col = (Element) cols.item(0);
                         	sql = sql + "(\""+col.getTextContent()+"\")";
                         	sql = sql + " REFERENCES ";
                        	sql = sql + "\""+con.getAttribute("refTable")+"\" ";
                        	NodeList refCols = con.getElementsByTagName("refColumn");
                         	Element refCol = (Element) refCols.item(0);
                         	sql = sql + "(\""+refCol.getTextContent()+"\")";
                         	sql2 = "";
                         			
                         }
                    	 else
                    	 {
                    		 String sssql =
                                     "ALTER TABLE \"" + tableName + "\" ADD CONSTRAINT \"" +
                                     con.getAttribute("name") + "\" " +
                                     con.getTextContent();
                    	 }
                    }
                   
                    
                    
                    conn.createStatement().executeUpdate(sql);
                    
                    if(!sql2.isEmpty())
                    	conn.createStatement().executeUpdate(sql2);
                }
            }

            //--------------------------------------
            // 4️⃣ CREATE TRIGGERS
            //--------------------------------------
            for (int i = 0; i < tables.getLength(); i++) {
                Element table = (Element) tables.item(i);
                NodeList trgs = table.getElementsByTagName("trigger");

                for (int t = 0; t < trgs.getLength(); t++) {
                    conn.createStatement()
                        .executeUpdate(trgs.item(t).getTextContent());
                }
            }

            conn.commit();
            resp.getWriter().println("Import completed successfully");

        } catch (Exception e) {
            resp.getWriter().println("Import failed: " + e.getMessage());
        }
    }
}
