package com.concordance.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.concordance.utils.DBConnection;

public class DropDBServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
          try (Connection conn = DBConnection.getConnection();
               Statement st = conn.createStatement()) {

              conn.setAutoCommit(false);

              // Drop everything
              st.execute("DROP SCHEMA public CASCADE");
              st.execute("CREATE SCHEMA public");

              // Restore permissions (important!)
              st.execute("GRANT ALL ON SCHEMA public TO postgres");
              st.execute("GRANT ALL ON SCHEMA public TO public");

              conn.commit();
              resp.getWriter().println("Database reset successfully");

          } catch (Exception e) {
              resp.sendError(500, "DB reset failed: " + e.getMessage());
          }
        }
    }

