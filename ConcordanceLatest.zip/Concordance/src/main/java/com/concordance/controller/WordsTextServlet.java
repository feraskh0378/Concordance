package com.concordance.controller;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.concordance.dao.WordsDAO;
import com.concordance.dao.SongsDAO;
import com.concordance.model.Song;
import com.concordance.model.SongWord;
/*
data.append("WordId", wordID);
data.append("Word", word);
data.append("Song", song);
data.append("Verse", verse);
data.append("Line", line);
data.append("LinePlace", linePlace);
*/

public class WordsTextServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
	    	WordsDAO wordsDoa = new WordsDAO();
	    	SongsDAO songsDoa = new SongsDAO();
	    	wordsDoa.initConnection();
	    	songsDoa.initConnection();
	    	
	       ArrayList<Map<Integer, Map<Integer, SongWord>>> versesToShow = new ArrayList<Map<Integer, Map<Integer, SongWord>>>();	
    	   String inputWordId  = request.getParameter("WordId");
    	   String inputVerse  = request.getParameter("Verse");
    	   String viewId  = request.getParameter("ViewId");
    	   String phraseToSearch  = request.getParameter("Phrase");
    	   
    	   int nextVerse = 0;
           int prevVerse = 0;
    	   
    	  
    		   SongWord songWord = wordsDoa.getSongWord(Integer.parseInt(inputWordId));
    		   int songID = wordsDoa.getSongId(Integer.parseInt(inputWordId));
    		   Song songObject = songsDoa.getSong(songID); 
    		   Map<Integer, Map<Integer, Map<Integer, SongWord>>> songText  = songsDoa.getSongText(songID);
    		   int numberOfVerses = songText.size();
    	  
    	       	   
    	   int currentWordVerse = songWord.getVerse();
    	   if(Integer.parseInt(inputVerse) != 0)
    	   {
    		   currentWordVerse = Integer.parseInt(inputVerse);
    	   }
    	       	     	   
    	   versesToShow.add(songText.get(currentWordVerse));
    	
    	   if((currentWordVerse + 1) <= numberOfVerses)
    	   {    		      		   		  
    		   versesToShow.add(songText.get(currentWordVerse + 1));
    	   }
    	      	   
    	   if((currentWordVerse + 2) <= numberOfVerses)
    	   {    		         		   		 
    		   versesToShow.add(songText.get(currentWordVerse + 2));
    	   } 	  	   	   
                                   
           if(currentWordVerse < numberOfVerses)
           {
	        	nextVerse = currentWordVerse + 1;
           }
	        
	       if(currentWordVerse > 1)
	       {
	        	prevVerse = currentWordVerse + -1;
	       }
	       
	       ArrayList<SongWord[]> listWordsToMark = new ArrayList<SongWord[]>();
	       
	       if(!phraseToSearch.isEmpty())
	       {
	    	   String[] wordsInPhrase = phraseToSearch.split(" ");
	    	   SongWord[] songWordsToMark = new SongWord[wordsInPhrase.length];
	    	  
	    	   int searchIndex = 0;
	    	   for(int v =0;v < versesToShow.size();v++)
	    	   {
	    		   Map<Integer, Map<Integer, SongWord>> verse = versesToShow.get(v);
	    		   
	    		   for(Map.Entry<Integer,  Map<Integer, SongWord>> e : verse.entrySet())
		    	   {
	    			    Map<Integer, SongWord> line = e.getValue();    	
	    			    for(Map.Entry<Integer, SongWord> e1 : line.entrySet())
	    			    {
	    			    	SongWord word = e1.getValue();
	    			    	if(word.getWord().equals(wordsInPhrase[searchIndex]))
	    			    	{	    			    	
	    			    		songWordsToMark[searchIndex] = word;
	    			    		searchIndex++;
	    			    		if(searchIndex ==  wordsInPhrase.length)
	    			    		{
	    			    			listWordsToMark.add(songWordsToMark);
	    			    			searchIndex = 0;
	    			    			songWordsToMark = new SongWord[wordsInPhrase.length];
	    			    		}
	    			    	}
	    			    	else
	    			    	{
	    			    		searchIndex = 0;
	    			    	}	    			    	
	    			    }
		    	   }
	    	   }
	    	   for(SongWord[] arr : listWordsToMark)
	    	   {
	    		   for(SongWord word : arr)
	    		   {
	    			   word.setMark(true);
	    		   }
	    	   }
	    	   
	       }
	       else
	       if(!inputWordId.isEmpty())
	       {
	    	   for(int v =0;v < versesToShow.size();v++)
	    	   {
	    		   Map<Integer, Map<Integer, SongWord>> verse = versesToShow.get(v);
	    		   
	    		   for(Map.Entry<Integer,  Map<Integer, SongWord>> e : verse.entrySet())
		    	   {
	    			    Map<Integer, SongWord> line = e.getValue();    	
	    			    for(Map.Entry<Integer, SongWord> e1 : line.entrySet())
	    			    {
	    			    	SongWord word = e1.getValue();
	    			    	if(word.getId() == Integer.parseInt(inputWordId))
	    			    	{
	    			    		word.setMark(true);
	    			    	}
	    			    }
		    	   }
	    	   }
	       }
	    
	        
	       request.setAttribute("NextVerse", nextVerse);
	       request.setAttribute("PrevVerse", prevVerse);
	       request.setAttribute("ViewID", viewId);
	       request.setAttribute("WordId", inputWordId);
	       request.setAttribute("Phrase", phraseToSearch);
	       
	       request.setAttribute("SongTitle", songObject.getTitle());
	       request.setAttribute("WordTextData", versesToShow);
	       request.setAttribute("WordData", songWord.getWord());
	
	       
            
            
            // Forward request to JSP
            RequestDispatcher dispatcher = request.getRequestDispatcher("WordTextTab.jsp");
            dispatcher.forward(request, response);
    }
}
